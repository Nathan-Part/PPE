﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PPE
{
    class user
    {
        public int id { get; set; }
        public string nom { get; set; }
        public string prenom { get; set; }
        public string login { get; set; }
        public string mdp { get; set; }
        public int type { get; set; }
        public int id_type { get; set; }
        public string libelle { get; set; }

    }
}
