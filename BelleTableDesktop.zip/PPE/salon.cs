﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PPE
{
    class salon
    {
        public int id_salon { get; set; }

        public string nom { get; set; }

        public string date_salon { get; set; }

        public string lieu { get; set; }
    }
}
