Bienvenue sur la documentation de BelleTable vous retrouverez dans ce dossier 4 document :

document1_Prestataire.pdf -> information sur le prestataire
document2_Client.pdf -> information sur le client
document3_devis.pdf -> le devis
document4_video_docutilisateur.mp4 -> vidéo de présentation de l'application
document5_contenuesql.pdf -> image de la base de données

Pour récupérer la base de données en local aller dans le dossier ../BDD et récupéré le dossier BelleTableDesktop.sql


